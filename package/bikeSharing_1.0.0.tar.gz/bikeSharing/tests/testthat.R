library(testthat)
library(bikeSharing)

test_check("bikeSharing")
