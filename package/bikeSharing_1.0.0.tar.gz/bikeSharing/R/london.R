#' Pre-processed London bike sharing data
#'
#' London bike sharing data that has been standardized and grouped
#' in 8-hour time chunks. Pre-processing script can be found in
#' the raw_data/ directory.
#'
#' @format A data frame with 2185 rows and 14 variables:
#' \describe{
#'   \item{Date}{Date of observation, mm-dd, class: chr}
#'   \item{Hour_chunks}{8-hour time chunk: [0,8), [8,16), or [16,24), class: Factor, 3 levels}
#'   \item{Day}{Numeric day of the year 1-365, class: chr}
#'   \item{Is_weekend}{Weekend (1) or not weekend (0), class: Factor, 2 levels}
#'   \item{Is_holiday}{Holiday (1) or not holiday (0), class: Factor, 2 levels}
#'   \item{Season}{Autumn, Spring, Summer, or Winter, class: Factor, 4 levels}
#'   \item{Min_temp}{Daily minimum temperature in Celcius, class: num}
#'   \item{Max_temp}{Daily maximum temperature in Celcius, class: num}
#'   \item{Min_humidity}{Daily minimum humidity percentage, class: num}
#'   \item{Max_humidity}{Daily maximum humidity percentage, class: num}
#'   \item{Year}{Year 1 or Year 2, class: chr}
#'   \item{Wind_speed}{Average wind speed in m/s during time chunk, class: num}
#'   \item{Rain_or_snow}{Occrrence of any rain or snow (1) during time chunk or not (0), class: Factor, 2 levels}
#'   \item{Bike_count}{Number of bikes rented during time chunk, class: int}
#' }
"london"
